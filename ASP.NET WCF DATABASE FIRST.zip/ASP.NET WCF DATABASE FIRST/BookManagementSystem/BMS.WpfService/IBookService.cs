﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BMS.WpfService
{
    
    
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IBookService
    {

        [OperationContract]
        int AddBook(Books_138222 book);

        [OperationContract]
        int UpdateBook(Books_138222 book);

        [OperationContract]
        int DeleteBook(int id);

        [OperationContract]
        List<Books_138222> ShowBook();

        [OperationContract]
        Books_138222 SearchBook(int id);
    }
}
