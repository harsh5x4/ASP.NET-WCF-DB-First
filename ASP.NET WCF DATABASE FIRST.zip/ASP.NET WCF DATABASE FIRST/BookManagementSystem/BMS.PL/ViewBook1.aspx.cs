﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.BL;
using BMS.DAL.BookServiceReference;

namespace BMS.PL
{
    public partial class ViewBook1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                List<Books_138222> blist = BookBLL.ShowBookBLL();

                GridView1.DataSource = blist.ToList();
                GridView1.DataBind();

            }
            catch (SystemException ex)
            {
                lblerror.Text = ex.Message;
            }
        }


    }
}